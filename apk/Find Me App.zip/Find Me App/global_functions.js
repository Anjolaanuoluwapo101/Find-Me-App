//on back function,this how allows the user to go back to a previous accessibke layout

function OnBack() {
   if(addGuardianSmallLayout != 0){
      if(addGuardianSmallLayout.GetVisibility() != "Hide"){
         addGuardianSmallLayout.SetVisibility("Hide")
         return addGuardianSmallLayout = 0;
      } 
   }
   
   if(removeUserSmallLayout != 0){
     if(removeUserSmallLayout.GetVisibility() != "Hide"){
        removeUserSmallLayout.SetVisibility("Hide")
        return removeUserSmallLayout = 0;
     } 
   }
   
   if(guardianLayout != 0) {
      if(guardianLayout.GetVisibility() != "Hide") {
         guardianLayout.SetVisibility("Hide")
         return homeLayout.SetVisibility("Show")
      }
   }
   
   if(viewUserLayout != 0) {
      if(viewUserLayout.GetVisibility() != "Hide") {
         viewUserLayout.SetVisibility("Hide")
         return userLayout.SetVisibility("Show")
      }
   }
   
   if(userLayout != 0) {
      if(userLayout.GetVisibility() != "Hide") {
         userLayout.SetVisibility("Hide")
         return homeLayout.SetVisibility("Show")
      }
   }
   
}

function OnError( msg, line, file )
{
    var text =
        'Message: "' + msg + '"\n' +
        'Line: ' + line + '\n' +
        'File: "' + app.Uri2Path(file) + '"';

    app.Alert( text, "Received error message:" );
}

function getCurrentDateTime() {
   const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday',
      'Thursday', 'Friday', 'Saturday'
   ];
   const monthsOfYear = ['January', 'February', 'March', 'April',
      'May', 'June', 'July', 'August', 'September', 'October',
      'November', 'December'
   ];

   const now = new Date();

   const dayOfWeek = daysOfWeek[now.getDay()];
   const dayOfMonth = now.getDate();
   const month = monthsOfYear[now.getMonth()];
   const year = now.getFullYear();
   const hours = now.getHours();
   const minutes = now.getMinutes();
   const ampm = hours >= 12 ? 'pm' : 'am';

   const formattedTime = hours % 12 || 12; // Convert to 12-hour format
   const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;

   const dateTimeString =
      `${dayOfWeek}, ${dayOfMonth} ${month} ${year} - ${formattedTime}:${formattedMinutes}${ampm}`;

   return dateTimeString;
}

function urlEncodeString(inputString) {
   return encodeURIComponent(inputString);
}

function unixTimeStampToHumanReadable(unixTimeStamp) {
   const months = ["January", "February", "March", "April", "May",
      "June", "July", "August", "September", "October",
      "November", "December"
   ];
   const days = ["Sunday", "Monday", "Tuesday", "Wednesday",
      "Thursday", "Friday", "Saturday"
   ];

   const date = new Date(unixTimeStamp * 1000); // Convert to milliseconds
   const dayOfWeek = days[date.getDay()];
   const day = date.getDate();
   const month = months[date.getMonth()];
   const year = date.getFullYear();
   const hours = date.getHours();
   const minutes = date.getMinutes();
   const ampm = hours >= 12 ? 'pm' : 'am';
   const formattedHours = hours % 12 === 0 ? 12 : hours % 12;
   const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;

   const formattedDate =
      `${dayOfWeek}, ${day} ${month} ${year} - ${formattedHours}:${formattedMinutes}${ampm}`;
   return formattedDate;
}


function getCurrentUnixTimeStamp() {
   return Math.floor(Date.now() / 1000); // Divide by 1000 to convert milliseconds to seconds
}

function extractNumbersFromString(inputString) {
   var matches = inputString.match(/\d+/g);
   if(matches) {
      return matches.map(Number);
   }
}

function generateRandomWord(length) {
   const alphabet = 'abcdefghijklmnopqrstuvwxyz';
   let randomWord = '';

   for(let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * alphabet.length);
      randomWord += alphabet[randomIndex];
   }

   return randomWord;
}


function removeMutedAccounts(arr1, arr2) {
  // Create a copy of the first array
  const result = arr1.slice();
  
  // Loop through each element in the second array
  for (let i = 0; i < arr2.length; i++) {
    // Find the index of the matching element in the result array
    const index = result.indexOf(arr2[i]);
    
    // If a matching element is found, remove it from the result array
    if (index !== -1) {
      result.splice(index, 1);
    }
  }
  
  // Return the remaining elements in the result array
  return result;
}

function notificationMessageMaker(names) {
   if(names.length === 0) {
      return "No one has activated the SOS signal";
   } else if(names.length === 1) {
      return `${names[0]} has activated the SOS signal`;
   } else if(names.length === 2) {
      return `${names[0]} and ${names[1]} have activated their SOS signal`;
   } else {
      const n = names.length - 1;
      return `${names[0]} and ${n} others have activated their SOS signal`;
   }
}