//Note: When running background services on newer Huawei phones, you
//may need to go into the Android battery saving settings and enable 
//DroidScript to run in the background if you want background 
//notifications to work when the phone is locked.

//make some scripts available to the background service
app.Script("global_functions.js")

//variables needed by the Service.js
var oldNotif = ''; //stores the old content of the notification..helps determines if there's truly a notif change
var loc = '';

const APPSTORAGEPATH = app.GetPrivateFolder( "storage" ) ; //
const HTTPHOSTSERVICE = 'http://localhost:8000'

//Called when service is started.
function OnStart() {
   app.SetOnError(OnError);
   //Force service to foreground on newer devices (required).
   if(app.GetBuildNum() > 21) {
      app.SetPriority("high")
      app.SetInForeground("Find Me App Working In Background");
   }


   if(!app.FileExists(APPSTORAGEPATH+"/data.txt")) {
      return app.SendMessage("Missing file,Login Again")
      app.Exit(); //kill service
   } else {
      app.SendMessage('Service Started')
   }
}

//Called when we get a message from main app...
function OnMessage(msg) {
   if(msg == "asUser") {
      app.ShowPopup("SOS Beacon Activated! Your Guardians will be alerted" );
      return getGeoCode();
     
   } else if(msg == "asGuardian") {
      app.SendMessage("Users will now be tracked")
      setInterval(function(){
         checkForActivatedSOSUsers();
      },7000);
   }
}



//loc.SetOnChange(  ) is recurssive
function getGeoCode() {
   loc = app.CreateLocator("GPS,Network");
   loc.SetOnChange(loc_OnChange);
   loc.Start();
}

function loc_OnChange(pos) {
   if(!app.FileExists(APPSTORAGEPATH+"/data.txt") || app.ReadFile(APPSTORAGEPATH+"/userState.txt" ) == 0){
      app.SendMessage('Service stopped');
      app.Exit()//service stops 
   }
   var msg = pos.latitude + ", " + pos.longitude;
   //loc.Stop(); //this is because the Locator is an object that loops
   // Replace with your desired format (json, xml, etc.)
   var format = 'json';
   // Nominatim API endpoint

   var apiUrl =
      'https://nominatim.openstreetmap.org/reverse?format=' +
      format + '&lat=' + pos.latitude + '&lon=' + pos.longitude;
   // Set the user agent to identify the application
   var userAgent = generateRandomWord(12); //It's a free api and change in user agent prevents ban
   var xhr = new XMLHttpRequest();

   // Configure the request
   xhr.open('GET', apiUrl, true);
   xhr.setRequestHeader('User-Agent', userAgent);

   // Set up the event listener for when the request is completed
   xhr.onload = function() {
      if(xhr.status == 200) {
         // Parse the JSON response
         var data = JSON.parse(xhr.responseText);
         //app.SendMessage(data.display_name )
         //generate the time stamp at which a new location of the user was obtained.
         var timeStamp = getCurrentUnixTimeStamp(); 
         var location = urlEncodeString(data.display_name)
         var user_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];

         // Nominatim API endpoint
         var api_url =
            HTTPHOSTSERVICE + '/actions/as_a_user.php?user_unique_otp=' +
            user_unique_otp + '&location=' + data.display_name +
            '&update_user_location_SOS=true&timeStamp=' +
            timeStamp;

         // Create a new XMLHttpRequest instance
         var xhrr = new XMLHttpRequest();
         // Configure the request
         xhrr.open('GET', api_url, true);
         // Set up the event listener for when the request is completed
         xhrr.onload = function() {
            if(xhrr.status == 200) {
               app.SendMessage(xhrr.responseText)
            } else {
               app.SendMessage('Request failed:', xhrr.statusText);
            }
         };
         xhrr.send();//make api call to nomatim
      } else {
          app.SendMessage('Request failed:'+xhr.statusText);
      }
   };
   // Send the request
   xhr.send(); //send the user(account) current location to the backend

}



function checkForActivatedSOSUsers() {
   if(!app.FileExists(APPSTORAGEPATH+"/data.txt") || app.ReadFile(APPSTORAGEPATH+"/userState.txt" ) == 0){
      app.SendMessage('Service stopped');
      app.Exit()//service stops 
   }
   var guardian_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
   if(!app.FileExists( APPSTORAGEPATH+'/unixTimeStamp.txt' )){
      var timestamp = getCurrentUnixTimeStamp() - 600; //get update on users that have sounded their sos beacon within the last 10minutes
   }else{
      var timestamp = app.ReadFile( APPSTORAGEPATH+'/unixTimeStamp.txt' );
   }
   //app.SendMessage("Time Stamp is: "+ timestamp )
   // Create a new XMLHttpRequest instance
   var xhrr = new XMLHttpRequest();
    app.SendMessage(guardian_otp);
   // Configure the request
   xhrr.open('GET',HTTPHOSTSERVICE+"/actions/as_a_guardian.php?sos_activated_users=true&guardian_otp=" +guardian_otp + "&timestamp=" + timestamp, true);

   // Set up the event listener for when the request is completed
   xhrr.onload = function() {
      if(xhrr.status == 200) {
         //app.SendMessage(xhrr.responseText);
         //app.SendMessage(guardian_otp);
         var usersWithSOSBeaconActivated = JSON.parse(xhrr.responseText);
         //check if any of this users(accounts) have being muted 
         if(app.FileExists(APPSTORAGEPATH+"/mutedAccounts.txt" )){
            var mutedAccounts =JSON.parse(app.ReadFile(APPSTORAGEPATH+"/mutedAccounts.txt"));
            //seive out muted accounts (accounts muted by this account)
            usersWithSOSBeaconActivated = removeMutedAccounts(usersWithSOSBeaconActivated,mutedAccounts);
         }
         
         if(xhrr.responseText != oldNotif) { //ensures that notification an update from the previous
            var notifText = notificationMessageMaker(usersWithSOSBeaconActivated);
            var notify = app.CreateNotification();
            notify.SetMessage("Ticker", "Alert For Guardian",notifText);
            notify.Notify("SOS_Notification"); //display notification
            oldNotif = xhrr.responseText; //saves previous notifcation
         }
         //store the timestamp at which this request was made
         var lastRequestTimeStamp = getCurrentUnixTimeStamp();
         app.WriteFile(APPSTORAGEPATH+"/unixTimeStamp.txt",lastRequesTimeStamp, "ASCII")
      } else {
         console.error('Request failed:', xhrr.statusText);
      }
   };

   // Send the request
   xhrr.send();
}