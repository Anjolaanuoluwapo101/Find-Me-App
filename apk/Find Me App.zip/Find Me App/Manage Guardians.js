//The guardianLayout page allows a particular account to manage the other accounts monitoring him/her
//global variables used in this page..global variables can be declared anywhere outside of the function scope

//this UI is rendered for account type Guardians when trackUsersButton is clicked from the Guardian Home Page
function guardianLayoutFunction(previousLayout) {
   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
   guardianLayout = MUI.CreateLayout("linear", "VCenter,FillXY");
   // Create a scroll view for the list of guardians
   scrollViewForUser = app.CreateScroller(1, 0.75);
   scrollViewForUser.SetPadding(4, 4, 4, 4, "mm")
   listLayoutForUser = app.CreateLayout("linear", "Center,FillXY");
   //create refresh button 
   var refreshButton = MUI.CreateButtonRaisedO("Refresh Guardians List",0.5,0.1)
   refreshButton.SetOnTouch(function() {
      app.ShowProgress("Loading..." )
      getGuardianList()
   })
      // Create the buttons for removing users only
   var addGuardianButton = MUI.CreateButtonRaisedO("Add an account as your Guardian", 0.8,0.1);
   addGuardianButton.SetOnTouch(function() {
         showAddGuardianSmallPage()
      })
    //populate the scroller
   getGuardianList();
   //add scroller
   scrollViewForUser.AddChild(listLayoutForUser);
   guardianLayout.AddChild(scrollViewForUser);
   guardianLayout.AddChild(refreshButton)
   guardianLayout.AddChild(addGuardianButton)
   app.AddLayout(guardianLayout);
}


// Create a custom layout for each list item
function createListItemLayoutOfGuardians(guardianName, guardianOTP,guardianNumber) {
   var listItemLayoutParent = MUI.CreateLayout("linear","Horizontal");
   listItemLayoutParent.SetSize(-1,10,"mm")
   //listItemLayoutParent.SetMargins(0, 0, 0, 1.5, "mm")
   var column1 = app.CreateLayout("linear", "Vertical");
   var row1a = app.CreateLayout("linear", "FillXY")
   var row1aDetail = app.CreateText("NAME: " + guardianName, 0.6, -1, "Left")
   row1a.AddChild(row1aDetail)
   var row1b = app.CreateLayout("linear", "FillXY")
   var row1bDetail = app.CreateText("TEL: " + guardianNumber, 0.6, -1, "Left")
   row1b.AddChild(row1bDetail)
   column1.AddChild(row1a);
   column1.AddChild(row1b);
   var column2 = app.CreateLayout("linear", "FillXY")
   var removeGuardianButton = MUI.CreateButtonRaised("Remove Guardian->"+guardianOTP , 0.3, -1, "Bold")
   removeGuardianButton.SetOnTouch(function() {
      guardian_otp = extractNumbersFromString(this.GetText());
      removeGuardianButtonFunction(guardian_otp)
   })
   column2.AddChild(removeGuardianButton)
   listItemLayoutParent.AddChild(column1);
   listItemLayoutParent.AddChild(column2);
   return listItemLayoutParent;
}


function getGuardianList() {
   var user_otp;
   var check_if_scroll_view_is_populated = 0;
   if(app.FileExists(APPSTORAGEPATH+"/data.txt")) {
      user_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"]
   } else {
      app.ShowPopup("Please Grant Storage Permissions", "Long")
      launchHomeForGuardian(0);
   }
   // Create XMLHttpRequest
   var query = "unique_otp=" + user_otp +"&load_guardian_list=true";
   var xhr = new XMLHttpRequest();
   xhr.open("GET","http://localhost:8000/actions/as_a_user.php?" +query, true);
   xhr.onreadystatechange = function() {
      if(xhr.readyState === 4) {
         if(xhr.status === 200) {
            app.HideProgress()
            if(refreshForManageGuardiansScript == true) {
               scrollViewForUser.DestroyChild(listLayoutForUser)
               listLayoutForUser = app.CreateLayout("linear","Center,FillXY");
               check_if_scroll_view_is_populated = 1
            } else {
               refreshForManageGuardiansScript = true;
            }
            // Add multiple custom layouts to the listLayout
            var guardian_list = JSON.parse(xhr.responseText);
            if(guardian_list == "No Guardian Records") {
               return app.ShowPopup("No Guardian Records");
            }
    
            const guardian_list_processed = Object.keys(guardian_list);
            guardian_list_processed.forEach(unique_otp => {
               const guardian_details = guardian_list[unique_otp];
               listLayoutForUser.AddChild(createListItemLayoutOfGuardians(guardian_details["full_name"],unique_otp,guardian_details["mobile_num"]));
            });
            if(check_if_scroll_view_is_populated == 1) {
               scrollViewForUser.AddChild(listLayoutForUser)
            }
         }else{
            app.HideProgress();
            app.ShowPopup('Please try again by refreshing' )
         }
      }
   };
   xhr.onerror = function() {
      app.HideProgress();
      app.ShowPopup("An error occurred.");
   };
   xhr.send()
}


//allows a User type account to add Guardians via the Guardian unique otp
function showAddGuardianSmallPage() {
   addGuardianSmallLayout = MUI.CreateLayout("linear","VCenter,FillXY");
   addGuardianSmallLayout.SetBackColor("#AA000000");

   var addGuardianUI = app.CreateLayout("linear", "Vertical")
   var guardianOTPEdit = MUI.CreateTextEditOutline( 0.8,"Right","Account ID");
   var submitGuardianOTPButton = MUI.CreateButtonRaisedO("Submit",0.6);

   addGuardianUI.AddChild(guardianOTPEdit);
   addGuardianUI.AddChild(submitGuardianOTPButton);

   addGuardianSmallLayout.AddChild(addGuardianUI);
   //addGuardianSmallLayout.SetVisibility("Show");
   app.AddLayout(addGuardianSmallLayout);

   submitGuardianOTPButton.SetOnTouch(function() {
      var otpValue = guardianOTPEdit.GetText();
      if(!/^\d+$/.test(otpValue)) {
         app.ShowPopup("Invalid ID. Please enter numbers only.");
         return;
      } else {
         var user_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
         sendGuardianOTP(user_unique_otp, otpValue, "add")
      }

   });
}


function sendGuardianOTP(user_unique_otp, guardian_unique_otp, mode) {
   if(!/^\d+$/.test(guardian_unique_otp)) {
      app.ShowPopup("Invalid OTP. Please enter numbers only.");
      return;
   } else {
      // Use XMLHttpRequest to send OTP value to backend
      var xhr = new XMLHttpRequest();
      if(mode == "add") {
         var url ="http://localhost:8000/actions/as_a_user.php?user_otp=" +user_unique_otp + "&guardian_otp=" +guardian_unique_otp + "&add_guardian=true&mode=add";
      } else {
         var url ="http://localhost:8000/actions/as_a_user.php?user_otp=" +user_unique_otp + "&guardian_otp=" +guardian_unique_otp +"&remove_guardian=true&mode=remove"
      }
      xhr.open("GET", url, true);
      xhr.onload = function() {
         if(xhr.status === 200) {
            app.ShowPopup(xhr.responseText);
         } else {
            app.ShowPopup("Please try again.");
         }
      };
      xhr.onerror = function() {
         app.ShowPopup("An error occurred.");
      };
      xhr.send();
   }
}


///helps a User type account remove a particular guardian
function removeGuardianButtonFunction(guardianOTP) {
   var user_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
   sendGuardianOTP(user_unique_otp, guardianOTP, "remove")
}