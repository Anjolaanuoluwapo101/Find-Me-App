

//Called from the OTP page after Regstration is complete
//It can also be called from the OnStart function directly if User has logged in on the app before

//global variable used in this script



function showLoginPage(layout) {
   app.HideProgress();
   if(layout != 0) {
      layout.SetVisibility("Hide");
   }

   loginLayout = MUI.CreateLayout("linear", "VCenter,FillXY");
   var header = MUI.CreateTextH6("LOGIN" )
   var mobileEdit = MUI.CreateTextEditOutline(0.8,"Right","Phone No.",true);
   var passEdit = MUI.CreateTextEditOutline(0.8,"Right","Password",true);
   var submitButton = MUI.CreateButtonRaised("Submit");
   var regButton = MUI.CreateButtonRaised("Create New Account");
   regButton.SetMargins(0.01, 2, 0.01, 0.01, "mm")

   submitButton.SetOnTouch(function() {
      var mobile = mobileEdit.GetText();
      var password = passEdit.GetText();

      submitLogin(mobile, password)
   });

   regButton.SetOnTouch(function() {
     app.ShowProgress(  )
     return showRegistrationLayout(loginLayout)
   })
   
   loginLayout.AddChild(header)
   loginLayout.AddChild(mobileEdit);
   loginLayout.AddChild(passEdit);
   loginLayout.AddChild(submitButton);
   loginLayout.AddChild(regButton)

   app.AddLayout(loginLayout);

   //to improve ux
   //if the user has logged in before ...autofill
  if(app.FileExists(APPSTORAGEPATH+"/data.txt")){
     var privData = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt" ))
     mobileEdit.SetText(privData.mobile_num);
  }

}

function submitLogin(mobile, password) {
   if(!mobile || !password) {
      app.ShowPopup("Please fill in all fields.");
      return;
   }
   
   app.ShowProgress( )
   var xhr = new XMLHttpRequest();
   xhr.open("GET","http://localhost:8000/validation/login.php?mobile_num=" +mobile + "&password=" + password, true);
   //xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   xhr.onreadystatechange = function() {
      if(xhr.readyState === 4) {
         
         if(xhr.status === 200) {
               // Successful response from backend
            app.HideProgress();
            if(xhr.responseText == "NULL") {
               app.ShowPopup("Account does not exist")
            } else if(xhr.responseText == "Not Verified") {
               app.ShowPopup("Please verify your account,an email has been sent previously","Long");
               showotpPage(loginLayout);
            } else {
               //we get the whole account  details
               var privData = xhr.responseText;
               //alert(privData);
               privData = JSON.parse(privData);
               //var simpleCrypto = new SimpleCrypto(secretKey)
               //encodedPassword = simpleCrypto.encrypt(privateData["password"])
               privData["password"] = ''; //we don't need password saved locally
               app.WriteFile(APPSTORAGEPATH+"/data.txt", JSON.stringify(privData), "ASCII")
               launchHomeLayout(loginLayout);
            }
         } else {
            app.HideProgress()
            app.ShowPopup("Please try again later.");
         }
      }
   };
   xhr.send()
}