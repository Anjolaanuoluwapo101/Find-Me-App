//The userLayout page allows an account to manage other accounts under monitoring

//global variables used in this page..global variables can be declared anywhere outside of the function scope
var getUsersListInterval;//stores a setinterval function..not in use

//this UI is rendered for account type Guardians when trackUsersButton is clicked from the Guardian Home Page
function userLayoutFunction(previousLayout) {
   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
   userLayout = app.CreateLayout("linear", "VCenter,FillXY");
   // Create a scroll view for the list of guardians
   scrollViewForGuardian = app.CreateScroller(1, 0.75);
   scrollViewForGuardian.SetPadding(2, 2, 2, 2, "mm")
   listLayoutForGuardian = app.CreateLayout("linear","Center,F)illXY");
   
   //create refresh button
   var refreshButton = MUI.CreateButtonRaisedO("Refresh Users List", 0.8, -1)
   refreshButton.SetOnTouch(function() {
      app.ShowProgress("Loading....");
      getUsersList();
   })

   // Create the buttons for removing users only
   var removeUserButton = MUI.CreateButtonRaisedO("Remove Users", 0.8, -1,);
   removeUserButton.SetOnTouch(function() {
      showRemoveUserSmallPage()
   })

   //populate the scroller for the first time...
   getUsersList();
   //add scroller
   scrollViewForGuardian.AddChild(listLayoutForGuardian);
   userLayout.AddChild(scrollViewForGuardian);
   userLayout.AddChild(refreshButton)
   userLayout.AddChild(removeUserButton)
   app.AddLayout(userLayout);
}

// function using the data from getUsersList() function to populate the scrollview that displays users details
function createListItemLayout(mobile_num, full_name, sos = 0,lastseen = "N/A", user_otp) {
   var listItemLayoutParent = MUI.CreateLayout("linear","VCenter,FillXY");
   listItemLayoutParent.SetSize(-1,15,"mm" )
   listItemLayoutParent.SetPadding(2, 0, 2, 0, "mm")
   //listItemLayoutParent.SetBackColor("gray")
   var row1 = app.CreateLayout("linear", "Horizontal");
   var detail1 = app.CreateText("NAME: "+full_name, 0.3, -1,"AutoScale,AutoShrink,Bold,Multiline,Left")
   var detail2 = app.CreateText("Current Location: " + lastseen,0.6, -1, "AutoScale,AutoShrink,Multiline,Left")
   row1.AddChild(detail1);
   row1.AddChild(detail2);
   var row2 = app.CreateLayout("linear", "Horizontal");
   if(sos == 1) {
      var checkSOSButton = MUI.CreateButtonRaised("SOS BEACON HAS BEEN CLICKED: " + user_otp, 0.8, - 1,"red");
   } else {
      var checkSOSButton = MUI.CreateButtonRaisedO("SOS inactive,user is safe", -1, -1);
      checkSOSButton.SetEnabled(false);
   }
   checkSOSButton.SetOnTouch(function() {
      user_otp = extractNumbersFromString(this.GetText());
      //save the user_otp to a session key
      app.ShowProgress("Loading...." )
      app.SetData('userOtp',user_otp);
      app.SetData('name',full_name);
      viewUserFunction(userLayout);
   })
   row2.AddChild(checkSOSButton);
   listItemLayoutParent.AddChild(row1);
   listItemLayoutParent.AddChild(row2);
   return listItemLayoutParent;
}


//function helps retrieve the data from the backend that populates the scrollview
function getUsersList() {
   var guardian_otp;
   var check_if_scroll_view_is_populated;
   if(app.FileExists(APPSTORAGEPATH+"/data.txt")) {
      guardian_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
   } else {
      app.ShowPopup("Please Grant Storage Permissions", "Long")
      launchHomeForGuardian(0);
   }
   // Create XMLHttpRequest
   var timestamp = getCurrentUnixTimeStamp() - 180 ; //
   var query = "guardian_otp=" + guardian_otp + "&timestamp=" +
      timestamp + "&load_users_list=true";
   var xhr = new XMLHttpRequest();
   xhr.open("GET","http://localhost:8000/actions/as_a_guardian.php?" +query, true);
   xhr.onreadystatechange = function() {
      if(xhr.readyState === 4) {
         if(xhr.status === 200) {
            app.HideProgress();
            if(JSON.parse(xhr.responseText) == "No User Records") {
               return app.ShowPopup("No User Records");
            }
            if(refreshForManageUsersScript == true) {
               scrollViewForGuardian.DestroyChild(listLayoutForGuardian)
               listLayoutForGuardian = app.CreateLayout("linear", "Center,FillXY");
               check_if_scroll_view_is_populated = 1
            } else {
               refreshForManageUsersScript = true; //next fetch will be a refresh
            }
            // Add multiple custom layouts to the listLayout
            var users_list = JSON.parse(xhr.responseText);
            const users_list_processed = Object.keys(users_list);
            users_list_processed.forEach(unique_otp => {
              var  user_details = users_list[unique_otp];
               listLayoutForGuardian.AddChild(createListItemLayout(user_details["mobile_num"],user_details["full_name"],user_details["SOS"],user_details["last_seen_location"],unique_otp));
            });
            //this block helps repopulate the  scrollViewForGuardian if it's not empty
            if(check_if_scroll_view_is_populated == 1) {
               scrollViewForGuardian.AddChild(
                  listLayoutForGuardian)
            }
         }else{
            app.HideProgress();
            app.ShowPopup("Please try again" ,"Long")
         }
      }
   };
   xhr.onerror = function() {
      app.HideProgress();
      app.ShowPopup("An error occurred.","Long");
   };
   xhr.send()
}




function showRemoveUserSmallPage() {
   removeUserSmallLayout = MUI.CreateLayout("linear","VCenter,FillXY");
   removeUserSmallLayout.SetBackColor("#AA000000");

   var removeUserUI = MUI.CreateLayout("linear", "Vertical");
   var guardianOTPEdit = MUI.CreateTextEditOutline(0.8,"Right", "Account ID");
   var submitGuardianOTPButton = MUI.CreateButtonRaised("Submit", 0.6,-1);
   removeUserUI.AddChild(guardianOTPEdit);
   removeUserUI.AddChild(submitGuardianOTPButton);
   
   removeUserSmallLayout.AddChild(removeUserUI);
   //removeUserSmallLayout.SetVisibility("Show");
   app.AddLayout(removeUserSmallLayout);
   submitGuardianOTPButton.SetOnTouch(function() {
      var otpValue = guardianOTPEdit.GetText();
      if(!/^\d+$/.test(otpValue)) {
         return app.ShowPopup("Invalid ID. Please enter numbers only.");
      } else {
         var otpValue = guardianOTPEdit.GetText();
         var guardian_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
         sendUserOTP(guardian_unique_otp, otpValue)
      }
   });
}

function sendUserOTP(guardian_unique_otp, user_unique_otp) {
   if(!/^\d+$/.test(guardian_unique_otp)) {
      return app.ShowPopup("Invalid ID. Please enter numbers only.");
   } else {
      // Use XMLHttpRequest to send OTP value to backend
      var xhr = new XMLHttpRequest();
      var url =
         "http://localhost:8000/actions/as_a_guardian.php?user_otp=" +
         user_unique_otp + "&guardian_otp=" + guardian_unique_otp +
         "&remove_user=true";
      xhr.open("GET", url, true);

      xhr.onload = function() {
         if(xhr.status === 200) {
            app.ShowPopup(xhr.responseText);
         } else {
            app.ShowPopup("Failed Request. Please try again.");
         }
      };
      xhr.onerror = function() {
         app.ShowPopup("An error occurred,try again later.");
      };

      xhr.send();
   }
}