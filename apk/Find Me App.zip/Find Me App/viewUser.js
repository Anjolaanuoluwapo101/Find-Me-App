function viewUserFunction(previousLayout) {

   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
  
   viewUserLayout = app.CreateLayout("linear" ,"VCenter,FillXY")
   web = app.CreateWebView(1,1);
   web.SetBackColor("#00000000");
   web.SetPadding(1,1,1,1,"px" );
   viewUserLayout.AddChild(web);
   app.AddLayout( viewUserLayout );
   web.LoadUrl("html/viewUser.html");
}