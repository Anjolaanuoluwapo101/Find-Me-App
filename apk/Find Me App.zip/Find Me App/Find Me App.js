//Import Material UI for Designing
cfg.Light
cfg.MUI

//Global Variables ,all layout variables are created here
//utilized by Find Me App.js
var regLayout = 0,otpLayout = 0;

//utilized by Login.js
var loginLayout = 0;

//utilized by manage guardians.js
var guardianLayout = 0;
var addGuardianSmallLayout = 0;
var scrollViewForUser, listLayoutForUser;
//determines if guardians_list can be refreshed(utilized in manage guardians.js script)
var refreshForManageGuardiansScript = false;

//utilized by manage users.js
var userLayout = 0;
var removeUserSmallLayout = 0;
var scrollViewForGuardian,listLayoutForGuardian
//determines if users_list can be refreshed
var refreshForManageUsersScript = false;

//utilized by menu.js
var homeLayout = 0;
var startServiceMarker = 0;
var svc1; //the service is instantiated in this variables
var svc2 ;
var userState; //
var guardianState; //
var unixTimeStampWhenAppWasOpened;

//utilized by view user.js
var viewUserLayout = 0;

// Some variables for Registration page
var mobileEdit, govEdit, emailEdit, nameEdit, passEdit, passEditConfirm,genderSpinner;

const APPSTORAGEPATH = app.GetPrivateFolder( "storage" ) ; //
const HTTPHOST = "http://localhost:8000";

function OnStart() {
//load some other scripts
//app.Script("global_functions.js",true)
app.Script("Login.js",true)
//app.Script( "viewUser.js",true)
//app.Script("Manage Guardians.js",true)
//app.Script("Manage Users.js",true)
//app.Script("Menu.js",true);
   

   // this is done so that OnBack function can be called instead
   app.ShowProgress('Loading...' )
   app.EnableBackKey(false)

   //require permissions
   if(!app.CheckPermission("Location,ExtSDCard,Internal,External")) {
      app.GetPermission("Location,ExtSDCard,Internal,External")
   }

   //initialize Material UI
   var color = MUI.colors.teal
   app.InitializeUIKit(color.teal);

   if(app.FileExists(APPSTORAGEPATH+"/data.txt")) {
      return showLoginPage(0);
   } else {
      app.ShowPopup("Please create an account or login")
      return showRegistrationLayout(0)
   }
}

function showRegistrationLayout(layout) {
   app.HideProgress();
   if(layout != 0) {
      layout.SetVisibility("Hide")
   }

   // Create registration page UI
   regLayout = MUI.CreateLayout("linear", "VCenter,FillXY");
   var header = MUI.CreateTextH6("REGISTER ACCOUNT","grey" )
   nameEdit = MUI.CreateTextEditOutline(0.8,"Right","Full Name(Ensure you use all your names)",true);
   mobileEdit = MUI.CreateTextEditOutline(0.8, "Right","Phone No.",true);
   emailEdit = MUI.CreateTextEditOutline(0.8,"Right","Email", true);
   govEdit = MUI.CreateTextEditOutline(0.8,"Right","Local Government", true);
   passEdit = MUI.CreateTextEditOutline(0.8,"Right","Password", true);
   passEditConfirm = MUI.CreateTextEditOutline(0.8,"Right","Confirm Password", true);
   genderSpinner = MUI.CreateSpinner("Select Gender,Male,Female,Other",0.6,0.1);
   var submitButton = MUI.CreateButtonRaised("Register");

   var loginButtonFromRegPage = MUI.CreateButtonRaised("Already have an account?");
   loginButtonFromRegPage.SetMargins(0.01, 3, 0.01, 0.01, "mm")
   loginButtonFromRegPage.SetOnTouch(function() {
      app.ShowProgress(  )
      showLoginPage(regLayout)
   })

   submitButton.SetOnTouch(function() {
      if(passEdit.GetText() != passEditConfirm.GetText()){
         app.ShowPopup("Passwords don't match!")
         return;
      }
      
      if(genderSpinner.GetText() == "Select Gender"){
         app.ShowPopup( "Select Gender" )
         return
      }
      var mobile = mobileEdit.GetText();
      var government = govEdit.GetText();
      var email = emailEdit.GetText();
      var fullName = nameEdit.GetText();
      var password = passEdit.GetText();
      var gender = genderSpinner.GetText();
      submitRegistrationData(mobile, government, email,
         fullName, password, gender);
   });
   
   regLayout.AddChild(header)
   regLayout.AddChild(nameEdit);
   regLayout.AddChild(mobileEdit);
   regLayout.AddChild(govEdit);
   regLayout.AddChild(emailEdit);
   regLayout.AddChild(passEdit);
   regLayout.AddChild(passEditConfirm);
   regLayout.AddChild(genderSpinner);
   regLayout.AddChild(submitButton);
   regLayout.AddChild(loginButtonFromRegPage)

   app.AddLayout(regLayout);
}


//there should be a backend validation too.
function validateEmail(email) {
   var emailPattern =
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
   return emailPattern.test(email);
}

function validateFullName(name) {
   var namePattern =  /^[A-Za-z]+\s+[A-Za-z]+\s+[A-Za-z]+$/;
   return namePattern.test(name);
}

function validatePassword(password) {
   // Password should be at least 11 characters and include special symbols and numbers
   var passPattern =
      /^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{11,}$/;
   return passPattern.test(password);
}

function submitRegistrationData(mobile, government, email, fullName,password, gender) {
      // Input validation
   if(!/^\d+$/.test(mobile)) {
      //("Phone should only contain numbers.");
      return;
   }

   if(!validateEmail(email)) {
      app.ShowPopup("Invalid email address.");
      return;
   }

   if(!/^[a-zA-Z]+$/.test(government)) {
      app.ShowPopup(
         "Local Government should only contain letters.");
      return;
   }

   if(!validateFullName(fullName)) {
      app.ShowPopup(
         "Full Name should consist of three words (e.g., 'Anjola Akinsoyinu Jehpter')."
      );
      return;
   }

   if(!validatePassword(password)) {
      app.ShowPopup(
         "Password should be at least 11 characters and contain special symbols and numbers."
      );
      return;
   }

   // Create a JSON object with the collected data
   var data = {
      mobile_num: mobile,
      local_gov: government,
      email: email,
      full_name: fullName,
      gender: gender
   };
   
   app.ShowProgress("Loading....")

   var xhr = new XMLHttpRequest();
   var query = "mobile_num=" + mobile + "&local_gov=" + government +
      "&email=" + email + "&full_name=" + fullName + "&password=" +
      password + "&gender=" + gender;
   xhr.open('GET',
      HTTPHOST + '/validation/create_account.php?' +
      query,
      true);
   xhr.setRequestHeader('Content-type',
      'application/x-www-form-urlencoded');
   xhr.onload = function() {
      if(this.responseText == "Please check your Email for your unique ID") {
         app.ShowPopup("OTP Sent To Email" );
         showotpPage(regLayout);
      }else{
         app.HideProgress();
         app.ShowPopup(this.responseText,"Long" )
      }
   };

   // Convert data to JSON and send the request
   xhr.send(JSON.stringify(data));

   //save the privData
   app.WriteFile(APPSTORAGEPATH+"/data.txt", JSON.stringify(data), "ASCII")

}


function showotpPage(layout) {
   app.HideProgress();
   if(layout !== 0) {
      layout.SetVisibility("Hide");
   }
   otpLayout = MUI.CreateLayout("linear", "VCenter,FillXY");
   var header = MUI.CreateTextH6("FINISH UP!");

   var otpEdit = MUI.CreateTextEditOutline( 0.8,"Right","OTP",true);
   var sendButton = MUI.CreateButtonRaised("Submit OTP");
   sendButton.SetOnTouch(function() {
      var otp = otpEdit.GetText()
      sendOTP(otp)
   });
   
   otpLayout.AddChild(header);
   otpLayout.AddChild(otpEdit);
   otpLayout.AddChild(sendButton);

   app.AddLayout(otpLayout);

}


// Function to handle form submission
function sendOTP(otp) {
      // Validate OTP
   if(!(/^\d+$/.test(otp))) {
      app.ShowPopup("Invalid OTP. Please enter a number.");
      return;
   }

   var privData = app.ReadFile(APPSTORAGEPATH+"/data.txt")

   if(privData == '') {
      app.ShowPopup("Please Login Again","Long")
      showLoginPage(otpLayout)
   } else {
      //app.ShowPopup( "here" )
      privData = JSON.parse(privData);
   }
   app.ShowPopup("Loading..." )
   // Create XMLHttpRequest
   var xhr = new XMLHttpRequest();
   xhr.open("GET", HTTPHOST + "/validation/verify_id.php?otp=" +otp + "&mobile_num=" + privData.mobile_num , true);
   xhr.onreadystatechange = function() {
      if(xhr.readyState === 4) {
         if(xhr.status === 200) {
            if(xhr.responseText == "Verified") {
               app.HideProgress();
               app.ShowPopup("Welcome New User,your ID is "+otp,"Long");
                  //open login page            
               showLoginPage(otpLayout)
            } else {
               app.HideProgress();
               app.ShowPopup(xhr.responseText,"Long")
            }
         } else {
            app.HideProgress();
            app.ShowPopup("Form submission failed. Status: " +xhr.status,"Long");
         }
      }
   };
   xhr.send()
}

/**
* Beginning of Menu.js
**/
function launchHomeLayout(previousLayout) {
   app.HideProgress();
   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }


   // Create the Home Page UI
   homeLayout = MUI.CreateLayout("linear", "VCenter,FillXY");

   // Manage Guardians Button (This displays all the vitals of other accounts keeping track/monitoring an account)
   var manageGuardiansButton = MUI.CreateButtonRaisedO("Manage Guardians",0.8, 0.1);
   manageGuardiansButton.SetOnTouch(function() {
      if(guardianLayout == 0) {
         guardianLayoutFunction(homeLayout)
      } else {
         homeLayout.SetVisibility("Hide")
         guardianLayout.SetVisibility("Show")
      }
   })
   homeLayout.AddChild(manageGuardiansButton);
  
    // Manage Users Button
   var manageUsersButton = MUI.CreateButtonRaisedO("Manage Users",0.8, 0.1);
   manageUsersButton.SetOnTouch(function() {
      if(userLayout == 0) {
         userLayoutFunction(homeLayout)
      } else {
         homeLayout.SetVisibility("Hide")
         userLayout.SetVisibility("Show")
      }
   })
   homeLayout.AddChild(manageUsersButton);

   // SOS Button
   //retrieve state
   if(app.FileExists(APPSTORAGEPATH+"/userState.txt")) {
      userState = app.ReadFile(APPSTORAGEPATH+"/userState.txt")
   } else {
      userState = 0;
   }
   var sosButton = MUI.CreateButtonRaised("", 0.8, 0.1);
   if(userState == 0) {
      sosButton.SetText("Send out an SOS (If you're in trouble)");
      sosButton.SetBackColor("grey")
   } else if(userState == 1) {
      sosButton.SetText("SOS Service Running,Click to stop");
      sosButton.SetBackColor("red")
   }
   //SOS Button function
   sosButton.SetOnTouch(function() {
      //the if statement below only run once
      if(userState == 0) {
         userState = 1;
         app.WriteFile(APPSTORAGEPATH+"/userState.txt", userState, "ASCII"); //save button state
         svc1 = app.CreateService("this", "this",OnServiceReady);
         svc1.SetOnMessage(OnServiceMessage);
         //allow app to properly launch script before running the next two lines async
         setTimeout(function(){
            svc1.SendMessage('asUser'); 
         },2000);
         sosButton.SetBackColor("red");
         sosButton.SetText("SOS Service Running,Click to stop")
      } else {
         userState = 0;
         app.WriteFile(APPSTORAGEPATH+"/userState.txt", userState, "ASCII"); //save button state
         app.ShowPopup("Stopping Service,Please Wait..","Long")
         //stopping a service takes time so we run the next two lines async
         setTimeout(function(){
            sosButton.SetText("SOS");
            sosButton.SetBackColor("grey");
         },200);
      }
   });

   homeLayout.AddChild(sosButton);

   //Track Users Button
   //retrieve state
   if(app.FileExists(APPSTORAGEPATH+"/guardianState.txt")) {
      guardianState = app.ReadFile(APPSTORAGEPATH+"/guardianState.txt")
   } else {
      guardianState = 0;
   }
   var trackUsersButton = MUI.CreateButtonRaised("", 0.8, 0.1);
   if(guardianState == 0) {
      trackUsersButton.SetText("Track Other Accounts");
      trackUsersButton.SetBackColor("grey")
   } else if(guardianState == 1) {
      trackUsersButton.SetText("Tracking Other Accounts...");
      trackUsersButton.SetBackColor("red")
   }
   trackUsersButton.SetOnTouch(function() {
      //the if statement allows the button to be multi purpose
      if(guardianState == 0) {
         guardianState  = 1;
         app.WriteFile(APPSTORAGEPATH+"/guardianState.txt", guardianState, "ASCII");
         //Start/connect to our service.
         svc2 = app.CreateService("this", "this",OnServiceReady);
         //starting a service takes time so we run the next line async
         setTimeout(function(){
            svc2.SendMessage('asGuardian'); 
         },2000);
         svc2.SetOnMessage(OnServiceMessage);
         trackUsersButton.SetText("Tracking Other Accounts...");
         trackUsersButton.SetBackColor("red");
      } else {
         guardianState = 0;
         app.WriteFile(APPSTORAGEPATH+"/guardianState.txt", guardianState, "ASCII");
         app.ShowPopup("Stopping Service,Please Wait..","Long")
         //stopping a service takes time so we run the next two lines async
         setTimeout(function(){
            trackUsersButton.SetText("Track Other Accounts");
            trackUsersButton.SetBackColor("grey")
         },200);
      }
   });
   homeLayout.AddChild(trackUsersButton);

   // Logout Button
   var logoutButton = MUI.CreateButtonRaisedO("Logout", 0.8, 0.1);
   logoutButton.SetOnTouch(logoutButtonFunction)

   homeLayout.AddChild(logoutButton);
   app.AddLayout(homeLayout);
}

/**
For debugging purpose
**/
function OnServiceReady() {}
function OnServiceMessage(msg) {
    console.log(msg)
}
function logoutButtonFunction() {
    app.DestroyLayout(homeLayout);
    app.ShowProgress("Loading...");
    return showLoginPage(0);
}

/**
*End of Menu.js and beginning of Manage Guardian.js 
**/

//The guardianLayout page allows a particular account to manage the other accounts monitoring him/her
function guardianLayoutFunction(previousLayout) {
   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
   guardianLayout = MUI.CreateLayout("linear", "VCenter,FillXY");
   // Create a scroll view for the list of guardians
   scrollViewForUser = app.CreateScroller(1, 0.75);
   scrollViewForUser.SetPadding(4, 4, 4, 4, "mm")
   listLayoutForUser = app.CreateLayout("linear", "Center,FillXY");
   //create refresh button 
   var refreshButton = MUI.CreateButtonRaisedO("Refresh Guardians List",0.5,0.1)
   refreshButton.SetOnTouch(function() {
      app.ShowProgress("Loading..." )
      getGuardianList()
   })
   // Create the buttons for removing users only
   var addGuardianButton = MUI.CreateButtonRaisedO("Add an account as your Guardian", 0.8,0.1);
   addGuardianButton.SetOnTouch(function() {
       app.ShowProgress("Loading...");
       showAddGuardianSmallPage()
      })
    //populate the scroller
   getGuardianList();
   //add scroller
   scrollViewForUser.AddChild(listLayoutForUser);
   guardianLayout.AddChild(scrollViewForUser);
   guardianLayout.AddChild(refreshButton)
   guardianLayout.AddChild(addGuardianButton)
   app.AddLayout(guardianLayout);
}

// Create a custom layout for each list item
function createListItemLayoutOfGuardians(guardianName, guardianOTP,guardianNumber) {
   var listItemLayoutParent = MUI.CreateLayout("linear","Horizontal");
   listItemLayoutParent.SetSize(-1,10,"mm")
   //listItemLayoutParent.SetMargins(0, 0, 0, 1.5, "mm")
   var column1 = app.CreateLayout("linear", "Vertical");
   var row1a = app.CreateLayout("linear", "FillXY")
   var row1aDetail = app.CreateText("NAME: " + guardianName, 0.6, -1, "Left")
   row1a.AddChild(row1aDetail)
   var row1b = app.CreateLayout("linear", "FillXY")
   var row1bDetail = app.CreateText("TEL: " + guardianNumber, 0.6, -1, "Left")
   row1b.AddChild(row1bDetail)
   column1.AddChild(row1a);
   column1.AddChild(row1b);
   var column2 = app.CreateLayout("linear", "FillXY")
   var removeGuardianButton = MUI.CreateButtonRaised("Remove Guardian->"+guardianOTP , 0.3, -1, "Bold")
   removeGuardianButton.SetOnTouch(function() {
      guardian_otp = extractNumbersFromString(this.GetText());
      removeGuardianButtonFunction(guardian_otp)
   })
   column2.AddChild(removeGuardianButton)
   listItemLayoutParent.AddChild(column1);
   listItemLayoutParent.AddChild(column2);
   return listItemLayoutParent;
}


function getGuardianList() {
   var user_otp;
   var check_if_scroll_view_is_populated = 0;
   if(app.FileExists(APPSTORAGEPATH+"/data.txt")) {
      user_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"]
   } else {
      app.ShowPopup("Please Grant Storage Permissions", "Long")
      launchHomeForGuardian(0);
   }
   // Create XMLHttpRequest
   var query = "unique_otp=" + user_otp +"&load_guardian_list=true";
   var xhr = new XMLHttpRequest();
   xhr.open("GET", HTTPHOST + '/actions/as_a_user.php?' +query, true);
   xhr.onreadystatechange = function() {
      if(xhr.readyState === 4) {
         if(xhr.status === 200) {
            app.HideProgress()
            if(refreshForManageGuardiansScript == true) {
               scrollViewForUser.DestroyChild(listLayoutForUser)
               listLayoutForUser = app.CreateLayout("linear","Center,FillXY");
               check_if_scroll_view_is_populated = 1
            } else {
               refreshForManageGuardiansScript = true;
            }
            // Add multiple custom layouts to the listLayout
            var guardian_list = JSON.parse(xhr.responseText);
            if(guardian_list == "No Guardian Records") {
               return app.ShowPopup("No Guardian Records");
            }
    
            const guardian_list_processed = Object.keys(guardian_list);
            guardian_list_processed.forEach(unique_otp => {
               const guardian_details = guardian_list[unique_otp];
               listLayoutForUser.AddChild(createListItemLayoutOfGuardians(guardian_details["full_name"],unique_otp,guardian_details["mobile_num"]));
            });
            if(check_if_scroll_view_is_populated == 1) {
               scrollViewForUser.AddChild(listLayoutForUser)
            }
         }else{
            app.HideProgress();
            app.ShowPopup('Please try again by refreshing' )
         }
      }
   };
   xhr.onerror = function() {
      app.HideProgress();
      app.ShowPopup("An error occurred.");
   };
   xhr.send()
}


//allows a User type account to add Guardians via the Guardian unique otp
function showAddGuardianSmallPage() {
   addGuardianSmallLayout = MUI.CreateLayout("linear","VCenter,FillXY");
   addGuardianSmallLayout.SetBackColor("#AA000000");
   var addGuardianUI = app.CreateLayout("linear", "Vertical")
   var guardianOTPEdit = MUI.CreateTextEditOutline( 0.8,"Right","Account ID");
   var submitGuardianOTPButton = MUI.CreateButtonRaisedO("Submit",0.6);

   addGuardianUI.AddChild(guardianOTPEdit);
   addGuardianUI.AddChild(submitGuardianOTPButton);

   addGuardianSmallLayout.AddChild(addGuardianUI);
   app.AddLayout(addGuardianSmallLayout);
   app.HideProgress();
   submitGuardianOTPButton.SetOnTouch(function() {
      var otpValue = guardianOTPEdit.GetText();
      if(!/^\d+$/.test(otpValue)) {
         app.ShowPopup("Invalid ID. Please enter numbers only.");
         return;
      } else {
         var user_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
         sendGuardianOTP(user_unique_otp, otpValue, "add")
      }

   });
}

function sendGuardianOTP(user_unique_otp, guardian_unique_otp, mode) {
   if(!/^\d+$/.test(guardian_unique_otp)) {
      app.ShowPopup("Invalid OTP. Please enter numbers only.");
      return;
   } else {
      // Use XMLHttpRequest to send OTP value to backend
      var xhr = new XMLHttpRequest();
      if(mode == "add") {
         var url = HTTPHOST + "/actions/as_a_user.php?user_otp=" +user_unique_otp + "&guardian_otp=" +guardian_unique_otp + "&add_guardian=true&mode=add";
      } else {
         var url = HTTPHOST +  "/actions/as_a_user.php?user_otp=" +user_unique_otp + "&guardian_otp=" +guardian_unique_otp +"&remove_guardian=true&mode=remove"
      }
      xhr.open("GET", url, true);
      xhr.onload = function() {
         if(xhr.status === 200) {
            app.ShowPopup(xhr.responseText);
         } else {
            app.ShowPopup("Please try again.");
         }
      };
      xhr.onerror = function() {
         app.ShowPopup("An error occurred.");
      };
      xhr.send();
   }
}

//helps a User type account remove a particular guardian
function removeGuardianButtonFunction(guardianOTP) {
   var user_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
   sendGuardianOTP(user_unique_otp, guardianOTP, "remove")
}

/**
* End of Manage Guardian.js and beginning of Manage Users.js
**/
//The userLayout page allows an account to manage other accounts under monitoring
function userLayoutFunction(previousLayout) {
   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
   userLayout = app.CreateLayout("linear", "VCenter,FillXY");
   // Create a scroll view for the list of guardians
   scrollViewForGuardian = app.CreateScroller(1, 0.75);
   scrollViewForGuardian.SetPadding(2, 2, 2, 2, "mm")
   listLayoutForGuardian = app.CreateLayout("linear","Center,F)illXY");
   
   //create refresh button
   var refreshButton = MUI.CreateButtonRaisedO("Refresh Users List", 0.8, -1)
   refreshButton.SetOnTouch(function() {
      app.ShowProgress("Loading....");
      getUsersList();
   })

   // Create the buttons for removing users only
   var removeUserButton = MUI.CreateButtonRaisedO("Remove Users", 0.8, -1,);
   removeUserButton.SetOnTouch(function() {
      app.ShowProgress("Loading....");
      showRemoveUserSmallPage()
   })

   //populate the scroller for the first time...
   getUsersList();
   //add scroller
   scrollViewForGuardian.AddChild(listLayoutForGuardian);
   userLayout.AddChild(scrollViewForGuardian);
   userLayout.AddChild(refreshButton)
   userLayout.AddChild(removeUserButton)
   app.AddLayout(userLayout);
}

// function using the data from getUsersList() function to populate the scrollview that displays users details
function createListItemLayout(mobile_num, full_name, sos = 0,lastseen = "N/A", user_otp) {
   var listItemLayoutParent = MUI.CreateLayout("linear","VCenter,FillXY");
   listItemLayoutParent.SetSize(-1,15,"mm" );
   listItemLayoutParent.SetPadding(2, 0, 2, 0, "mm");
   var row1 = app.CreateLayout("linear", "Horizontal");
   var detail1 = app.CreateText("NAME: "+full_name, 0.3, -1,"AutoScale,AutoShrink,Bold,Multiline,Left")
   var detail2 = app.CreateText("Current Location: " + lastseen,0.6, -1, "AutoScale,AutoShrink,Multiline,Left")
   row1.AddChild(detail1);
   row1.AddChild(detail2);
   var row2 = app.CreateLayout("linear", "Horizontal");
   if(sos == 1) {
      var checkSOSButton = MUI.CreateButtonRaised("SOS BEACON HAS BEEN CLICKED: " + user_otp, 0.8, - 1,"red");
   } else {
      var checkSOSButton = MUI.CreateButtonRaisedO("SOS inactive,user is safe", -1, -1);
      checkSOSButton.SetEnabled(false);
   }
   checkSOSButton.SetOnTouch(function() {
      user_otp = extractNumbersFromString(this.GetText());
      //save the user_otp to a session key
      app.ShowProgress("Loading...." )
      app.SetData('userOtp',user_otp);
      app.SetData('name',full_name);
      viewUserFunction(userLayout);
   })
   row2.AddChild(checkSOSButton);
   listItemLayoutParent.AddChild(row1);
   listItemLayoutParent.AddChild(row2);
   return listItemLayoutParent;
}


//function helps retrieve the data from the backend that populates the scrollview
function getUsersList() {
   var guardian_otp;
   var check_if_scroll_view_is_populated;
   if(app.FileExists(APPSTORAGEPATH+"/data.txt")) {
      guardian_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
   } else {
      app.ShowPopup("Please Grant Storage Permissions", "Long")
      launchHomeForGuardian(0);
   }
   // Create XMLHttpRequest
   var timestamp = getCurrentUnixTimeStamp() - 180 ; //
   var query = "guardian_otp=" + guardian_otp + "&timestamp=" +
      timestamp + "&load_users_list=true";
   var xhr = new XMLHttpRequest();
   xhr.open("GET",HTTPHOST + "/actions/as_a_guardian.php?" +query, true);
   xhr.onreadystatechange = function() {
      if(xhr.readyState === 4) {
         if(xhr.status === 200) {
            app.HideProgress();
            if(JSON.parse(xhr.responseText) == "No User Records") {
               return app.ShowPopup("No User Records");
            }
            if(refreshForManageUsersScript == true) {
               scrollViewForGuardian.DestroyChild(listLayoutForGuardian)
               listLayoutForGuardian = app.CreateLayout("linear", "Center,FillXY");
               check_if_scroll_view_is_populated = 1
            } else {
               refreshForManageUsersScript = true; //next fetch will be a refresh
            }
            // Add multiple custom layouts to the listLayout
            var users_list = JSON.parse(xhr.responseText);
            const users_list_processed = Object.keys(users_list);
            users_list_processed.forEach(unique_otp => {
              var  user_details = users_list[unique_otp];
               listLayoutForGuardian.AddChild(createListItemLayout(user_details["mobile_num"],user_details["full_name"],user_details["SOS"],user_details["last_seen_location"],unique_otp));
            });
            //this block helps repopulate the  scrollViewForGuardian if it's not empty
            if(check_if_scroll_view_is_populated == 1) {
               scrollViewForGuardian.AddChild(
                  listLayoutForGuardian)
            }
         }else{
            app.HideProgress();
            app.ShowPopup("Please try again" ,"Long")
         }
      }
   };
   xhr.onerror = function() {
      app.HideProgress();
      app.ShowPopup("An error occurred.","Long");
   };
   xhr.send()
}

function showRemoveUserSmallPage() {
   removeUserSmallLayout = MUI.CreateLayout("linear","VCenter,FillXY");
   removeUserSmallLayout.SetBackColor("#AA000000");

   var removeUserUI = MUI.CreateLayout("linear", "Vertical");
   var guardianOTPEdit = MUI.CreateTextEditOutline(0.8,"Right", "Account ID");
   var submitGuardianOTPButton = MUI.CreateButtonRaised("Submit", 0.6,-1);
   removeUserUI.AddChild(guardianOTPEdit);
   removeUserUI.AddChild(submitGuardianOTPButton);
   
   removeUserSmallLayout.AddChild(removeUserUI);
   app.AddLayout(removeUserSmallLayout);
   app.HideProgress();
   submitGuardianOTPButton.SetOnTouch(function() {
      var otpValue = guardianOTPEdit.GetText();
      if(!/^\d+$/.test(otpValue)) {
         return app.ShowPopup("Invalid ID. Please enter numbers only.");
      } else {
         var otpValue = guardianOTPEdit.GetText();
         var guardian_unique_otp = JSON.parse(app.ReadFile(APPSTORAGEPATH+"/data.txt"))["unique_otp"];
         sendUserOTP(guardian_unique_otp, otpValue)
      }
   });
}

function sendUserOTP(guardian_unique_otp, user_unique_otp) {
   if(!/^\d+$/.test(guardian_unique_otp)) {
      return app.ShowPopup("Invalid ID. Please enter numbers only.");
   } else {
      // Use XMLHttpRequest to send OTP value to backend
      var xhr = new XMLHttpRequest();
      var url =
         HTTPHOST + "/actions/as_a_guardian.php?user_otp=" +
         user_unique_otp + "&guardian_otp=" + guardian_unique_otp +
         "&remove_user=true";
      xhr.open("GET", url, true);

      xhr.onload = function() {
         if(xhr.status === 200) {
            app.ShowPopup(xhr.responseText);
         } else {
            app.ShowPopup("Failed Request. Please try again.");
         }
      };
      xhr.onerror = function() {
         app.ShowPopup("An error occurred,try again later.");
      };
      xhr.send();
   }
}

/**
*End of Manage Users.js and beginning of viewUser.js
**/
function viewUserFunction(previousLayout) {

   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
  
   viewUserLayout = app.CreateLayout("linear" ,"VCenter,FillXY")
   web = app.CreateWebView(1,1);
   web.SetBackColor("#00000000");
   web.SetPadding(1,1,1,1,"px" );
   viewUserLayout.AddChild(web);
   app.AddLayout( viewUserLayout );
   web.LoadUrl("html/viewUser.html");
}

/**
*End of viewUser.js and beginning of global function.js 
**/
//on back function,this how allows the user to go back to a previous accessibke layout

function OnBack() {
   if(addGuardianSmallLayout != 0){
      if(addGuardianSmallLayout.GetVisibility() != "Hide"){
         addGuardianSmallLayout.SetVisibility("Hide")
         return addGuardianSmallLayout = 0;
      } 
   }
   
   if(removeUserSmallLayout != 0){
     if(removeUserSmallLayout.GetVisibility() != "Hide"){
        removeUserSmallLayout.SetVisibility("Hide")
        return removeUserSmallLayout = 0;
     } 
   }
   
   if(guardianLayout != 0) {
      if(guardianLayout.GetVisibility() != "Hide") {
         guardianLayout.SetVisibility("Hide")
         return homeLayout.SetVisibility("Show")
      }
   }
   
   if(viewUserLayout != 0) {
      if(viewUserLayout.GetVisibility() != "Hide") {
         viewUserLayout.SetVisibility("Hide")
         return userLayout.SetVisibility("Show")
      }
   }
   
   if(userLayout != 0) {
      if(userLayout.GetVisibility() != "Hide") {
         userLayout.SetVisibility("Hide")
         return homeLayout.SetVisibility("Show")
      }
   }
   
}

function OnError( msg, line, file )
{
    var text =
        'Message: "' + msg + '"\n' +
        'Line: ' + line + '\n' +
        'File: "' + app.Uri2Path(file) + '"';

    app.Alert( text, "Received error message:" );
}

function getCurrentDateTime() {
   const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday',
      'Thursday', 'Friday', 'Saturday'
   ];
   const monthsOfYear = ['January', 'February', 'March', 'April',
      'May', 'June', 'July', 'August', 'September', 'October',
      'November', 'December'
   ];

   const now = new Date();

   const dayOfWeek = daysOfWeek[now.getDay()];
   const dayOfMonth = now.getDate();
   const month = monthsOfYear[now.getMonth()];
   const year = now.getFullYear();
   const hours = now.getHours();
   const minutes = now.getMinutes();
   const ampm = hours >= 12 ? 'pm' : 'am';

   const formattedTime = hours % 12 || 12; // Convert to 12-hour format
   const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;

   const dateTimeString =
      `${dayOfWeek}, ${dayOfMonth} ${month} ${year} - ${formattedTime}:${formattedMinutes}${ampm}`;

   return dateTimeString;
}

function urlEncodeString(inputString) {
   return encodeURIComponent(inputString);
}

function unixTimeStampToHumanReadable(unixTimeStamp) {
   const months = ["January", "February", "March", "April", "May",
      "June", "July", "August", "September", "October",
      "November", "December"
   ];
   const days = ["Sunday", "Monday", "Tuesday", "Wednesday",
      "Thursday", "Friday", "Saturday"
   ];

   const date = new Date(unixTimeStamp * 1000); // Convert to milliseconds
   const dayOfWeek = days[date.getDay()];
   const day = date.getDate();
   const month = months[date.getMonth()];
   const year = date.getFullYear();
   const hours = date.getHours();
   const minutes = date.getMinutes();
   const ampm = hours >= 12 ? 'pm' : 'am';
   const formattedHours = hours % 12 === 0 ? 12 : hours % 12;
   const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;

   const formattedDate =
      `${dayOfWeek}, ${day} ${month} ${year} - ${formattedHours}:${formattedMinutes}${ampm}`;
   return formattedDate;
}


function getCurrentUnixTimeStamp() {
   return Math.floor(Date.now() / 1000); // Divide by 1000 to convert milliseconds to seconds
}

function extractNumbersFromString(inputString) {
   var matches = inputString.match(/\d+/g);
   if(matches) {
      return matches.map(Number);
   }
}

function generateRandomWord(length) {
   const alphabet = 'abcdefghijklmnopqrstuvwxyz';
   let randomWord = '';

   for(let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * alphabet.length);
      randomWord += alphabet[randomIndex];
   }
   return randomWord;
}


function removeMutedAccounts(arr1, arr2) {
  // Create a copy of the first array
  const result = arr1.slice();
  
  // Loop through each element in the second array
  for (let i = 0; i < arr2.length; i++) {
    // Find the index of the matching element in the result array
    const index = result.indexOf(arr2[i]);
    
    // If a matching element is found, remove it from the result array
    if (index !== -1) {
      result.splice(index, 1);
    }
  }
  // Return the remaining elements in the result array
  return result;
}

function notificationMessageMaker(names) {
   if(names.length === 0) {
      return "No one has activated the SOS signal";
   } else if(names.length === 1) {
      return `${names[0]} has activated the SOS signal`;
   } else if(names.length === 2) {
      return `${names[0]} and ${names[1]} have activated their SOS signal`;
   } else {
      const n = names.length - 1;
      return `${names[0]} and ${n} others have activated their SOS signal`;
   }
}