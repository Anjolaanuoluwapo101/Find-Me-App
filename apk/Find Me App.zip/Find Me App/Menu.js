function launchHomeLayout(previousLayout) {
   app.HideProgress()
   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }


   // Create the Home Page UI
   homeLayout = MUI.CreateLayout("linear", "VCenter,FillXY");

   // Manage Guardians Button (This displays all the vitals of other accounts keeping track/monitoring an account)
   var manageGuardiansButton = MUI.CreateButtonRaisedO("Manage Guardians",0.8, 0.1);
   manageGuardiansButton.SetOnTouch(function() {
      if(guardianLayout == 0) {
         guardianLayoutFunction(homeLayout)
      } else {
         homeLayout.SetVisibility("Hide")
         guardianLayout.SetVisibility("Show")
      }
   })
   homeLayout.AddChild(manageGuardiansButton);
  
    // Manage Users Button
   var manageUsersButton = MUI.CreateButtonRaisedO("Manage Users",0.8, 0.1);
   manageUsersButton.SetOnTouch(function() {
      if(userLayout == 0) {
         userLayoutFunction(homeLayout)
      } else {
         homeLayout.SetVisibility("Hide")
         userLayout.SetVisibility("Show")
      }
   })
   homeLayout.AddChild(manageUsersButton);

   // SOS Button
   //retrieve state
   if(app.FileExists(APPSTORAGEPATH+"/userState.txt")) {
      userState = app.ReadFile(APPSTORAGEPATH+"/userState.txt")
   } else {
      userState = 0;
   }
   var sosButton = MUI.CreateButtonRaised("", 0.8, 0.1);
   if(userState == 0) {
      sosButton.SetText("Send out an SOS (If you're in trouble)");
      sosButton.SetBackColor("grey")
   } else if(userState == 1) {
      sosButton.SetText("SOS Service Running,Click to stop");
      sosButton.SetBackColor("red")
   }
   //SOS Button function
   sosButton.SetOnTouch(function() {
      //the if statement below only run once
      if(userState == 0) {
         userState = 1;
         app.WriteFile(APPSTORAGEPATH+"/userState.txt", userState, "ASCII"); //save button state
         svc1 = app.CreateService("this", "this",OnServiceReady);
         svc1.SetOnMessage(OnServiceMessage);
         //allow app to properly launch script before running the next two lines async
         setTimeout(function(){
            svc1.SendMessage('asUser'); 
         },2000);
         sosButton.SetBackColor("red");
         sosButton.SetText("SOS Service Running,Click to stop")
         //userState = 1;
      } else {
         userState = 0;
         app.WriteFile(APPSTORAGEPATH+"/userState.txt", userState, "ASCII"); //save button state
         //svc1.Stop();
         app.ShowPopup("Stopping Service,Please Wait..","Long")
         //stopping a service takes time so we run the next two lines async
         setTimeout(function(){
            sosButton.SetText("SOS");
            sosButton.SetBackColor("grey");
         },200);
         userState = 0;
      }
   });

   homeLayout.AddChild(sosButton);

   //Track Users Button
   //retrieve state
   if(app.FileExists(APPSTORAGEPATH+"/guardianState.txt")) {
      guardianState = app.ReadFile(APPSTORAGEPATH+"/guardianState.txt")
   } else {
      guardianState = 0;
   }
   var trackUsersButton = MUI.CreateButtonRaised("", 0.8, 0.1);
   if(guardianState == 0) {
      trackUsersButton.SetText("Track Other Accounts");
      trackUsersButton.SetBackColor("grey")
   } else if(guardianState == 1) {
      trackUsersButton.SetText("Tracking Other Accounts...");
      trackUsersButton.SetBackColor("red")
   }
   trackUsersButton.SetOnTouch(function() {
      //the if statement allows the button to be multi purpose
      if(guardianState == 0) {
         guardianState  = 1;
         app.WriteFile(APPSTORAGEPATH+"/guardianState.txt", guardianState, "ASCII");
         //Start/connect to our service.
         svc2 = app.CreateService("this", "this",OnServiceReady);
         //starting a service takes time so we run the next line async
         setTimeout(function(){
            svc2.SendMessage('asGuardian'); 
         },2000);
         svc2.SetOnMessage(OnServiceMessage);
         trackUsersButton.SetText("Tracking Other Accounts...");
         trackUsersButton.SetBackColor("red")
         //guardianState = 1;
      } else {
         guardianState = 0;
         app.WriteFile(APPSTORAGEPATH+"/guardianState.txt", guardianState, "ASCII");
         //svc2.Stop();
         app.ShowPopup("Stopping Service,Please Wait..","Long")
         //stopping a service takes time so we run the next two lines async
         setTimeout(function(){
            trackUsersButton.SetText("Track Other Accounts");
            trackUsersButton.SetBackColor("grey")
         },200);
         //guardianState = 0;
      }
   });
   homeLayout.AddChild(trackUsersButton);

   // Logout Button
   var logoutButton = MUI.CreateButtonRaisedO("Logout", 0.8, 0.1);
   logoutButton.SetOnTouch(logoutButtonFunction)

   homeLayout.AddChild(logoutButton);
   app.AddLayout(homeLayout);
}


/**
FUNCTIONS THAT COMMUNICATE WITH SERVICE(works both User Account and Guardian Account)
**/

function OnServiceReady() {
   
}

function OnServiceMessage(msg) {
    console.log(msg)
}

/**

**/
function logoutButtonFunction() {
    app.DestroyLayout(homeLayout);
    app.ShowProgress( )
    return showLoginPage(0);
    //app.ShowPopup("Coming Soon");
}