To understand this app 
Please follow this paradigm
-SOS App.js
-Login.js
-Menu.js
    -There are two functions here that branch into two different scripts:
        -userLayout //this layout is a page where an account manage the other account he/she is tracking
        -guardianLayout //this layout leads to a page where an account can manage the other accounts tracking him/her(if SOS beacon is activated)

user or userState is associated with the functionality for getting tracked
guardian or guardianState is associated with the functionality for tracking someone or  'user'
the State is a variable used to keep track of which functionality is turned on/off