var viewUserLayout = 0;

function viewUserFunction(previousLayout) {

   if(previousLayout != 0) {
      if(previousLayout.GetVisibility() != "Hide") {
         previousLayout.SetVisibility("Hide")
      }
   }
  
   viewUserLayout = app.CreateLayout("linear" ,"VCenter,FillXY")
   web = app.CreateWebView(1,1);
   web.SetBackColor("#00000000");
   web.SetPadding(1,1,1,1,"px" )
   viewUserLayout.AddChild(web);
   app.AddLayout( viewUserLayout );
   app.SetData('userOtp',123);
   localStorage.setItem('userOtp',123);
   web.LoadUrl("html/viewUser.html")
}


function getUserImmediateLocation() {
   var check_if_scroll_view_is_populated;
   // Use XMLHttpRequest to send OTP value to backend
   var xhr = new XMLHttpRequest();
   var url =
      "http://localhost:8000/Women%20App%20Server/guardian to backend/Guardian_Backend_to_Guardian_Frontend.php?latest_location=true&user_otp=" +app.GetData('userOtp');
   xhr.open("GET", url, true);

   xhr.onload = function() {
      if(xhr.status === 200) {
         //app.ShowPopup(xhr.responseText);
         return JSON.parse(xhr.responseText);
         
      } else {
         app.ShowPopup("Failed Request. Please try again.");
      }
   };

   xhr.onerror = function() {
      app.ShowPopup("An error occurred,try again later.");
   };

   xhr.send();
}



async function getUserLocationHistory() {
   var check_if_scroll_view_is_populated;
   // Use XMLHttpRequest to send OTP value to backend
   var xhr = new XMLHttpRequest();
   var url =
      "http://localhost:8000/Women%20App%20Server/guardian to backend/Guardian_Backend_to_Guardian_Frontend.php?location_history=true&user_otp=" +app.GetData('userOtp');
   xhr.open("GET", url, true);

   xhr.onload = function() {
      if(xhr.status === 200) {
         //location history is always gotten inverted(ranked in descending order from latest to oldest)...so we flip it before sending inside webview
         //return JSON.parse(xhr.responseText);
         return xhr.responseText;
       } else {
         app.ShowPopup("Failed Request. Please try again.");
      }
   };

   xhr.onerror = function() {
      app.ShowPopup("An error occurred,try again later.");
   };

   xhr.send();
}

function hello(){
app.Alert('hello' )
}