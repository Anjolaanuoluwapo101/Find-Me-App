//app.Execute("app.SetData('userOtp',123)");
//app.Execute("app.Alert(app.GetData('userOtp'))");
function showSmallPage(divId) {
 var smallPage = document.getElementById('smallPage' + divId);
 smallPage.style.display = 'block';
}

function hideSmallPage(divId) {
 var smallPage = document.getElementById('smallPage' + divId);
 smallPage.style.display = 'none';
}


function textualLocationUpdate() {
 var location_history_container = document.getElementById('location_history_container');
 if (location_history_container.innerHTML == '') {
  getUserLocationHistory(function(result) {
   var location_history_list = JSON.parse(result).reverse(); //this is because backend gets the location in a descinding order
   location_history_list.forEach(function(item) {
    location_history_container.innerHTML +=
    `
    <div class="w3-bar-item w3-light-grey w3-margin-bottom location_data">
    <b>Location: </b>${item.location}<br>
    <b>At: </b><span>${unixTimeStampToHumanReadable(item.timestamp)}</span>
    </div>
    `;
   })
  });
 } else {
  getUserImmediateLocation(function(result) {
   var latest_location = JSON.parse(result);
   var locationDataDivs = document.querySelectorAll(".location_data");
   var lastLocationDataDiv = locationDataDivs[locationDataDivs.length - 1];
   var spanElement = lastLocationDataDiv.querySelector("span");
   var spanContent = spanElement.textContent;
   if (spanContent != unixTimeStampToHumanReadable(latest_location.timestamp)) {
    location_history_container.innerHTML +=
    `
    <div class="w3-bar-item w3-light-grey w3-margin-bottom location_data">
    <b>Location: </b>${latest_location.location}<br>
    <b>At: </b><span>${unixTimeStampToHumanReadable(latest_location.timestamp)}</span>
    </div>
    `;
   }
  });
 }
}

//two helper functions that work in tandem with textuaLlocationUpdate
function getUserLocationHistory(callback) {
 // Use XMLHttpRequest to send OTP value to backend
 var xhr = new XMLHttpRequest();
 //var user_otp = localStorage.getItem('userOtp');
 var url = "http://localhost:8000/actions/as_a_guardian.php?location_history=true&user_otp="+ app.GetData('userOtp');
 xhr.open("GET",
  url,
  true);

 xhr.onload = function() {
  if (xhr.status === 200) {
   callback(xhr.responseText);
  } else {
   app.ShowPopup("Failed Request. Please try again.");
  }
 };

 xhr.onerror = function() {
  app.ShowPopup("An error occurred,try again later.");
 };

 xhr.send();
}
function getUserImmediateLocation(callback) {
 // Use XMLHttpRequest to send OTP value to backend
 var xhr = new XMLHttpRequest();
 var url =
 "http://localhost:8000/actions/as_a_guardian.php?latest_location=true&user_otp="+app.GetData('userOtp');
 xhr.open("GET", url, true);

 xhr.onload = function() {
  if (xhr.status === 200) {
   callback(xhr.responseText);
  } else {
   app.ShowPopup("Failed Request. Please try again.");
  }
 };

 xhr.onerror = function() {
  app.ShowPopup("An error occurred,try again later.");
 };

 xhr.send();
}


function initializeMap() {
 // Initialize the map with an initial zoom level and center
 const map = L.map('map').setView([51.505, -0.09], 13);

 // Add a tile layer with multiple zoom levels
 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  maxZoom: 19,
 }).addTo(map);

 // Initialize a marker with an initial location
 let marker = L.marker([51.5, -0.09]).addTo(map);

 // Function to update marker's position randomly
 function updateMarkerLocation() {
  const newLat = 51.5 + Math.random() * 0.1 - 0.05;
  const newLng = -0.09 + Math.random() * 0.1 - 0.05;
  marker.setLatLng([newLat, newLng]).update();

  // Pan the map to the new marker location
  map.panTo([newLat, newLng]);
 }

 // Update the marker's position every 10 seconds
 setInterval(updateMarkerLocation, 10000);
}


function unixTimeStampToHumanReadable(unixTimeStamp) {
 const months = ["January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
 ];
 const days = ["Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
 ];

 const date = new Date(unixTimeStamp * 1000); // Convert to milliseconds
 const dayOfWeek = days[date.getDay()];
 const day = date.getDate();
 const month = months[date.getMonth()];
 const year = date.getFullYear();
 const hours = date.getHours();
 const minutes = date.getMinutes();
 const ampm = hours >= 12 ? 'pm': 'am';
 const formattedHours = hours % 12 === 0 ? 12: hours % 12;
 const formattedMinutes = minutes < 10 ? '0' + minutes: minutes;

 const formattedDate =
 `${dayOfWeek}, ${day} ${month} ${year} - ${formattedHours}:${formattedMinutes}${ampm}`;
 return formattedDate;
}


function muteNotification() {
 app.Execute(`
  var privDirectory = app.GetPrivateFolder('storage') + '/mutedAccounts.txt';
  if(app.FileExists(privDirectory)){
   var privData = JSON.parse(app.ReadFile(privDirectory))
  }else{
   var privData = [];
  }
  privData.push(app.GetData('name'));
  app.WriteFile(privDirectory,JSON.stringify(privData),'ASCII');
 `)
 alert('Done!');
}


function unmuteNotification() {
 app.Execute(`
  var privDirectory = app.GetPrivateFolder('storage') + '/mutedAccounts.txt';
  if(app.FileExists(privDirectory)){
   var privData = JSON.parse(app.ReadFile(privDirectory))
   var privData = privData.filter((element) => element !== app.GetData('name'));
   app.WriteFile(privDirectory,JSON.stringify(privData),'ASCII');
  }
 `)
 alert('Done!');
}